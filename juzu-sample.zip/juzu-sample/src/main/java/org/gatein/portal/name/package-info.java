@org.juzu.Application

@Assets(
        scripts = {
                @Script(src = "js/jquery-1.7.1.min.js")
        }
)
package org.gatein.portal.{{name}};

import org.juzu.plugin.asset.Assets;
import org.juzu.plugin.asset.Script;
import org.juzu.plugin.asset.Stylesheet;